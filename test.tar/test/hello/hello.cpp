/*************************************************************************
	> File Name: hello.cpp
  > Author: xuhehe
  > mail: xuhehe@360.cn
	> Created Time: Thu Jul 21 10:38:20 2016
 ************************************************************************/

#include<iostream>
using namespace std;

void Sayhello(){
	cout<<"hi , boy"<<endl;
}
