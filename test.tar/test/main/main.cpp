/*************************************************************************
	> File Name: main.c
  > Author: xuhehe
  > mail: xuhehe@360.cn
	> Created Time: Thu Jul 21 10:37:12 2016
 ************************************************************************/

#include<stdio.h>
#include "../include/hello.h"

int main(){
	Sayhello();
}
