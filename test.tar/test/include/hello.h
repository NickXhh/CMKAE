/*************************************************************************
	> File Name: hello.h
  > Author: xuhehe
  > mail: xuhehe@360.cn
	> Created Time: Thu Jul 21 10:39:58 2016
 ************************************************************************/

#include<iostream>
using namespace std;


void Sayhello();
